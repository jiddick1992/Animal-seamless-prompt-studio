let data=[], selected=null;
const $=id=>document.getElementById(id);
function parseCSV(text){
 const rows=[]; let row=[], cell='', q=false;
 for(let i=0;i<text.length;i++){
   let c=text[i],n=text[i+1];
   if(c==='"'&&q&&n==='"'){cell+='"';i++;continue}
   if(c==='"'){q=!q;continue}
   if(c===','&&!q){row.push(cell);cell='';continue}
   if((c==='\n'||c==='\r')&&!q){
     if(c==='\r'&&n==='\n')i++;
     row.push(cell);cell='';
     if(row.length)rows.push(row); row=[]; continue
   }
   cell+=c
 }
 if(cell||row.length){row.push(cell);rows.push(row)}
 const h=rows.shift();
 return rows.map(r=>Object.fromEntries(h.map((x,i)=>[x,r[i]||''])));
}
function csvCell(s){return '"'+String(s??'').replaceAll('"','""')+'"'}
function filtered(){
 const q=$('q').value.toLowerCase(), a=$('animal').value, s=$('style').value, st=$('status').value;
 return data.filter(x=>
   (!q||Object.values(x).join(' ').toLowerCase().includes(q)) &&
   (!a||x.Animal===a) && (!s||x['Pattern Style']===s) && (!st||x['Asset Status']===st)
 );
}
function fillFilters(){
 [...new Set(data.map(x=>x.Animal))].sort().forEach(v=>$('animal').insertAdjacentHTML('beforeend',`<option>${v}</option>`));
 [...new Set(data.map(x=>x['Pattern Style']))].sort().forEach(v=>$('style').insertAdjacentHTML('beforeend',`<option>${v}</option>`));
}
function render(){
 const f=filtered();
 $('stats').innerHTML=`<span class="badge">${f.length} hasil</span><span class="badge">${data.length} total</span>`;
 $('list').innerHTML=f.slice(0,100).map(x=>`<div class="card">
   <div class="title">${x.ID}. ${x.Title}</div>
   <div class="muted">${x.Animal} · ${x['Pattern Style']} · ${x.Category}</div>
   <pre>${x.Prompt}</pre>
   <div><b>Keywords:</b> ${x['Keywords (30)']}</div>
   <div class="row">
     <button onclick="pick(${x.ID})">Pilih & Copy</button>
     <button class="secondary" onclick="copyText(${JSON.stringify(x.Prompt)})">Copy Prompt</button>
   </div>
 </div>`).join('') || '<div class="card">Tidak ada hasil.</div>';
}
function pick(id){selected=data.find(x=>+x.ID===id); if(selected) copyText(selected.Prompt)}
async function copyText(t){try{await navigator.clipboard.writeText(t)}catch(e){prompt('Copy manual:',t)}}
function loadText(t){
 data=parseCSV(t);
 $('animal').innerHTML='<option value="">Semua hewan</option>';
 $('style').innerHTML='<option value="">Semua style</option>';
 fillFilters(); render();
}
$('file').onchange=e=>{const f=e.target.files[0]; if(!f)return; const r=new FileReader(); r.onload=()=>loadText(r.result); r.readAsText(f,'UTF-8')};
$('loadDefault').onclick=async()=>{
 try{
   const r=await fetch('1000_animal_seamless_microstock_prompts.csv');
   loadText(await r.text());
 }catch(e){alert('Jika membuka index.html langsung, gunakan tombol Pilih CSV. Atau jalankan server lokal: python -m http.server 8000')}
};
['q','animal','style','status'].forEach(id=>$(id).oninput=render);
$('export').onclick=()=>{
 const f=filtered(), h=Object.keys(data[0]||{});
 const out=[h.map(csvCell).join(',')].concat(f.map(r=>h.map(k=>csvCell(r[k])).join(','))).join('\n');
 const a=document.createElement('a');
 a.href=URL.createObjectURL(new Blob([out],{type:'text/csv;charset=utf-8'}));
 a.download='filtered_microstock_prompts.csv'; a.click();
};
